int func1(float xx);

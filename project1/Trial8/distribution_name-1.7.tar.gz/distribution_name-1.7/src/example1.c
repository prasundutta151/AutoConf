# include <stdio.h>
# include <stdlib.h>
# include <nrutil.h>
# include <nr.h>


# include "example1.h"



int main (int argc, char * argv[]){

  long seed;

  seed = -1232;
  printf("This is example1 with output %d\n", func1(1.));
  printf("One random number between 0. and 1.: %f\n", ran0(&seed));

  return EXIT_SUCCESS;
}

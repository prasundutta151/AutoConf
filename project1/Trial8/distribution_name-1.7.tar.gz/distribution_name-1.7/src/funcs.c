# include <math.h>
# include "example1.h"

int func1(float xx){

  return exp(5);
}
